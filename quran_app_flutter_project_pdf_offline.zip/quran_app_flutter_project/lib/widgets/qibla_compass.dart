import 'dart:math';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class QiblaCompass extends StatelessWidget {
  final double qiblaDirection;
  final double compassHeading;

  const QiblaCompass({
    required this.qiblaDirection,
    required this.compassHeading,
  });

  @override
  Widget build(BuildContext context) {
    final relativeAngle = (qiblaDirection - compassHeading) * pi / 180;

    return Container(
      width: 300,
      height: 300,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            AppTheme.goldLight,
            AppTheme.goldAccent.withOpacity(0.3),
            AppTheme.goldPrimary.withOpacity(0.2),
          ],
        ),
        border: Border.all(color: AppTheme.goldPrimary, width: 4),
        boxShadow: [
          BoxShadow(
            color: AppTheme.goldDark.withOpacity(0.5),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Transform.rotate(
            angle: -compassHeading * pi / 180,
            child: CustomPaint(
              size: Size(280, 280),
              painter: CompassDialPainter(),
            ),
          ),
          Transform.rotate(
            angle: relativeAngle,
            child: Container(
              width: 280,
              height: 280,
              child: CustomPaint(
                painter: QiblaNeedlePainter(),
              ),
            ),
          ),
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [AppTheme.goldAccent, AppTheme.goldPrimary],
              ),
              border: Border.all(color: AppTheme.goldDark, width: 3),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.goldDark.withOpacity(0.6),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Icon(
              Icons.mosque,
              color: Colors.white,
              size: 30,
            ),
          ),
        ],
      ),
    );
  }
}

class CompassDialPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 20;

    final outerPaint = Paint()
      ..color = AppTheme.goldPrimary
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawCircle(center, radius, outerPaint);

    for (int i = 0; i < 360; i += 10) {
      final angle = i * pi / 180;
      final isMain = i % 90 == 0;
      final isMinor = i % 30 == 0;

      final startRadius = isMain ? radius - 20 : (isMinor ? radius - 15 : radius - 8);
      final start = Offset(
        center.dx + startRadius * sin(angle),
        center.dy - startRadius * cos(angle),
      );
      final end = Offset(
        center.dx + radius * sin(angle),
        center.dy - radius * cos(angle),
      );

      final tickPaint = Paint()
        ..color = isMain ? AppTheme.goldDark : AppTheme.goldPrimary
        ..strokeWidth = isMain ? 3 : (isMinor ? 2 : 1);
      canvas.drawLine(start, end, tickPaint);
    }

    final directions = {'N': 0, 'E': 90, 'S': 180, 'W': 270};
    directions.forEach((label, angle) {
      final a = angle * pi / 180;
      final pos = Offset(
        center.dx + (radius - 40) * sin(a),
        center.dy - (radius - 40) * cos(a),
      );
      final textPainter = TextPainter(
        text: TextSpan(
          text: label,
          style: TextStyle(
            color: label == 'N' ? Colors.red : AppTheme.goldDark,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      );
      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(pos.dx - textPainter.width / 2, pos.dy - textPainter.height / 2),
      );
    });
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class QiblaNeedlePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final length = size.height / 2 - 30;

    final path = Path()
      ..moveTo(center.dx, center.dy - length)
      ..lineTo(center.dx - 12, center.dy)
      ..lineTo(center.dx, center.dy + 30)
      ..lineTo(center.dx + 12, center.dy)
      ..close();

    final gradient = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        AppTheme.goldAccent,
        AppTheme.goldPrimary,
        AppTheme.goldDark,
      ],
    );

    final paint = Paint()
      ..shader = gradient.createShader(Rect.fromCenter(
        center: center,
        width: size.width,
        height: size.height,
      ))
      ..style = PaintingStyle.fill;

    canvas.drawPath(path, paint);

    final borderPaint = Paint()
      ..color = AppTheme.goldDark
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawPath(path, borderPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
