import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../database/quran_database.dart';
import '../services/audio_service.dart';

class SurahReaderScreen extends StatefulWidget {
  final int surahId;
  final String surahName;
  final int versesCount;

  const SurahReaderScreen({
    required this.surahId,
    required this.surahName,
    required this.versesCount,
  });

  @override
  _SurahReaderScreenState createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  List<Map<String, dynamic>> ayahs = [];
  String selectedReciter = "مشاري راشد العفاسي";
  final AudioService _audioService = AudioService();
  bool isLoading = true;
  bool isPlaying = false;
  Duration? duration;
  Duration position = Duration.zero;

  @override
  void initState() {
    super.initState();
    _loadSurah();
    _setupAudioListeners();
  }

  void _setupAudioListeners() {
    _audioService.playerStateStream.listen((state) {
      if (mounted) setState(() => isPlaying = state.playing);
    });
    _audioService.durationStream.listen((d) {
      if (mounted) setState(() => duration = d);
    });
    _audioService.positionStream.listen((p) {
      if (mounted) setState(() => position = p);
    });
  }

  Future<void> _loadSurah() async {
    final data = await QuranDatabase.getAyahs(widget.surahId);
    setState(() {
      ayahs = data;
      isLoading = false;
    });
  }

  Future<void> _playSurah() async {
    try {
      await _audioService.playSurah(
        reciterName: selectedReciter,
        surahNumber: widget.surahId,
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("تعذر تشغيل الصوت")),
      );
    }
  }

  String _formatDuration(Duration d) {
    final minutes = d.inMinutes.toString().padLeft(2, '0');
    final seconds = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.surahName, style: TextStyle(fontFamily: 'Amiri')),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: AppTheme.goldGradient)),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: AppTheme.goldPrimary))
          : Column(
              children: [
                Container(
                  margin: EdgeInsets.all(15),
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                  decoration: BoxDecoration(
                    gradient: AppTheme.goldGradient,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.goldDark.withOpacity(0.4),
                        blurRadius: 10,
                        offset: Offset(0, 5),
                      ),
                    ],
                  ),
                  child: DropdownButton<String>(
                    value: selectedReciter,
                    isExpanded: true,
                    dropdownColor: AppTheme.goldLight,
                    underline: SizedBox(),
                    icon: Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 30),
                    style: TextStyle(color: AppTheme.goldDark, fontSize: 17, fontWeight: FontWeight.bold),
                    items: AudioService.reciters.keys.map((r) {
                      return DropdownMenuItem(
                        value: r,
                        child: Text(r, style: TextStyle(color: AppTheme.goldDark)),
                      );
                    }).toList(),
                    onChanged: (v) => setState(() => selectedReciter = v!),
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.all(15),
                    itemCount: ayahs.length,
                    itemBuilder: (context, index) {
                      final ayah = ayahs[index];
                      return Container(
                        margin: EdgeInsets.only(bottom: 20),
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppTheme.goldPrimary, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: AppTheme.goldAccent.withOpacity(0.2),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Icon(Icons.menu_book, color: AppTheme.goldPrimary, size: 25),
                                Container(
                                  padding: EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: AppTheme.goldPrimary, width: 2),
                                  ),
                                  child: Text(
                                    "${ayah['ayah_number']}",
                                    style: TextStyle(
                                      color: AppTheme.goldDark,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 15),
                            Text(
                              ayah['text_uthmani'],
                              style: TextStyle(fontSize: 26, height: 2.2, fontFamily: 'Amiri'),
                              textAlign: TextAlign.right,
                            ),
                            Divider(color: AppTheme.goldPrimary, thickness: 1),
                            Text(
                              "تفسير السعدي:",
                              style: TextStyle(
                                color: AppTheme.goldDark,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(height: 5),
                            Text(
                              ayah['tafseer_saadi'] ?? '',
                              style: TextStyle(fontSize: 17, height: 1.8, color: Colors.black87),
                              textAlign: TextAlign.right,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          gradient: AppTheme.goldGradient,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SliderTheme(
              data: SliderThemeData(
                activeTrackColor: Colors.white,
                inactiveTrackColor: Colors.white30,
                thumbColor: Colors.white,
                trackHeight: 4,
              ),
              child: Slider(
                value: position.inSeconds.toDouble(),
                max: duration?.inSeconds.toDouble() ?? 1.0,
                onChanged: (v) => _audioService.seek(Duration(seconds: v.toInt())),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_formatDuration(position), style: TextStyle(color: Colors.white)),
                Text(_formatDuration(duration ?? Duration.zero), style: TextStyle(color: Colors.white)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: Icon(Icons.replay_10, color: Colors.white, size: 35),
                  onPressed: () {
                    final newPos = position - Duration(seconds: 10);
                    _audioService.seek(newPos < Duration.zero ? Duration.zero : newPos);
                  },
                ),
                IconButton(
                  icon: Icon(
                    isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill,
                    color: Colors.white,
                    size: 65,
                  ),
                  onPressed: () {
                    if (isPlaying) {
                      _audioService.pause();
                    } else {
                      _playSurah();
                    }
                  },
                ),
                IconButton(
                  icon: Icon(Icons.forward_10, color: Colors.white, size: 35),
                  onPressed: () {
                    final newPos = position + Duration(seconds: 10);
                    if (duration != null && newPos > duration!) {
                      _audioService.seek(duration!);
                    } else {
                      _audioService.seek(newPos);
                    }
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _audioService.dispose();
    super.dispose();
  }
}
