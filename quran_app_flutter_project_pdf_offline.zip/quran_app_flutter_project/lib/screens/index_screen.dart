import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../database/quran_database.dart';
import '../models/surah.dart';
import 'surah_reader_screen.dart';

class IndexScreen extends StatefulWidget {
  @override
  _IndexScreenState createState() => _IndexScreenState();
}

class _IndexScreenState extends State<IndexScreen> {
  List<Surah> surahs = [];
  List<Surah> filteredSurahs = [];
  TextEditingController searchController = TextEditingController();
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSurahs();
  }

  Future<void> _loadSurahs() async {
    final data = await QuranDatabase.getAllSurahs();
    setState(() {
      surahs = data.map((m) => Surah.fromMap(m)).toList();
      filteredSurahs = surahs;
      isLoading = false;
    });
  }

  void _filterSurahs(String query) {
    setState(() {
      filteredSurahs = surahs.where((surah) {
        return surah.nameArabic.contains(query) ||
            surah.nameEnglish.toLowerCase().contains(query.toLowerCase()) ||
            surah.id.toString().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("فهرس القرآن الكريم", style: TextStyle(fontFamily: 'Amiri')),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: AppTheme.goldGradient)),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppTheme.goldLight, Colors.white],
          ),
        ),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(15),
              padding: EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: AppTheme.goldPrimary, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.goldDark.withOpacity(0.2),
                    blurRadius: 10,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: TextField(
                controller: searchController,
                onChanged: _filterSurahs,
                decoration: InputDecoration(
                  icon: Icon(Icons.search, color: AppTheme.goldPrimary),
                  hintText: "ابحث عن سورة...",
                  hintStyle: TextStyle(color: Colors.grey),
                  border: InputBorder.none,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 15),
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                gradient: AppTheme.goldGradient,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildInfoItem("114", "سورة"),
                  Container(width: 1, height: 30, color: Colors.white54),
                  _buildInfoItem("6236", "آية"),
                  Container(width: 1, height: 30, color: Colors.white54),
                  _buildInfoItem("30", "جزء"),
                ],
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: isLoading
                  ? Center(child: CircularProgressIndicator(color: AppTheme.goldPrimary))
                  : ListView.builder(
                      padding: EdgeInsets.symmetric(horizontal: 15),
                      itemCount: filteredSurahs.length,
                      itemBuilder: (context, index) {
                        final surah = filteredSurahs[index];
                        return _buildSurahCard(surah);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(String number, String label) {
    return Column(
      children: [
        Text(number, style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
        Text(label, style: TextStyle(color: Colors.white70, fontSize: 14)),
      ],
    );
  }

  Widget _buildSurahCard(Surah surah) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SurahReaderScreen(
              surahId: surah.id,
              surahName: surah.nameArabic,
              versesCount: surah.versesCount,
            ),
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.goldPrimary, width: 1.5),
          boxShadow: [
            BoxShadow(
              color: AppTheme.goldAccent.withOpacity(0.3),
              blurRadius: 8,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 55,
              height: 55,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [AppTheme.goldAccent, AppTheme.goldPrimary],
                ),
                border: Border.all(color: AppTheme.goldDark, width: 2),
              ),
              child: Center(
                child: Text(
                  "${surah.id}",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
            ),
            SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    surah.nameArabic,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.goldDark,
                      fontFamily: 'Amiri',
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    surah.nameEnglish,
                    style: TextStyle(color: Colors.grey[600], fontSize: 14),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: surah.revelationType == 'مكية' 
                        ? AppTheme.goldAccent.withOpacity(0.3)
                        : AppTheme.goldPrimary.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    surah.revelationType,
                    style: TextStyle(
                      color: AppTheme.goldDark,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  "${surah.versesCount} آية",
                  style: TextStyle(color: Colors.grey[700], fontSize: 13),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
