import 'package:flutter/material.dart';
import 'package:pdfrx/pdfrx.dart';
import '../theme/app_theme.dart';

/// Opens the bundled Mushaf PDF. The PDF is packaged in the APK, so no
/// network connection is needed to read its pages.
class MushafPdfScreen extends StatelessWidget {
  const MushafPdfScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المصحف الشريف'),
        flexibleSpace: Container(
          decoration: const BoxDecoration(gradient: AppTheme.goldGradient),
        ),
      ),
      body: PdfViewer.asset(
        'assets/mushaf.pdf',
        params: const PdfViewerParams(),
      ),
    );
  }
}
