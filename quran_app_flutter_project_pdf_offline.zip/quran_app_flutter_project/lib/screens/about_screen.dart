import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("عن التطبيق والإصدار"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: AppTheme.goldGradient)),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppTheme.goldLight, Colors.white],
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.menu_book, size: 100, color: AppTheme.goldPrimary),
                SizedBox(height: 20),
                Text(
                  "تطبيق القرآن الكريم الشامل",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.goldDark,
                    fontFamily: 'Amiri',
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "الإصدار: 1.0.0 (V 1.0)",
                  style: TextStyle(fontSize: 18, color: Colors.grey[700]),
                ),
                SizedBox(height: 40),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  decoration: BoxDecoration(
                    gradient: AppTheme.goldGradient,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.goldDark.withOpacity(0.4),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                  child: Text(
                    "كتابه تم بواسطة / عاطف سيد",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Amiri',
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  "جميع الحقوق محفوظة © 2026",
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
