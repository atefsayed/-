import 'dart:async';
import 'package:flutter/material.dart';
import 'package:adhan/adhan.dart';
import '../theme/app_theme.dart';
import '../services/prayer_service.dart';
import '../services/qibla_service.dart';
import '../widgets/qibla_compass.dart';

class PrayerTimesScreen extends StatefulWidget {
  @override
  _PrayerTimesScreenState createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  PrayerTimes? prayerTimes;
  String? nextPrayerName;
  Duration? timeUntilNext;
  double? qiblaDirection;
  double compassHeading = 0;
  bool isLoading = true;
  String? errorMessage;
  Timer? _timer;
  StreamSubscription? _compassSubscription;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final times = await PrayerService.getPrayerTimes();
      if (times == null) {
        setState(() {
          errorMessage = "لم نتمكن من تحديد موقعك. يرجى تفعيل GPS.";
          isLoading = false;
        });
        return;
      }

      final qibla = await QiblaService.getQiblaDirection();

      _compassSubscription = QiblaService.getCompassStream().listen((heading) {
        if (mounted) {
          setState(() => compassHeading = heading);
        }
      });

      _timer = Timer.periodic(Duration(seconds: 1), (_) {
        if (mounted && prayerTimes != null) {
          setState(() {
            nextPrayerName = PrayerService.getNextPrayer(prayerTimes!);
            timeUntilNext = PrayerService.getTimeUntilNextPrayer(prayerTimes!);
          });
        }
      });

      setState(() {
        prayerTimes = times;
        qiblaDirection = qibla;
        nextPrayerName = PrayerService.getNextPrayer(times);
        timeUntilNext = PrayerService.getTimeUntilNextPrayer(times);
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = "حدث خطأ: $e";
        isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _compassSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("مواقيت الصلاة والقبلة", style: TextStyle(fontFamily: 'Amiri')),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: AppTheme.goldGradient)),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadData,
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppTheme.goldLight, Colors.white],
          ),
        ),
        child: isLoading
            ? Center(child: CircularProgressIndicator(color: AppTheme.goldPrimary))
            : errorMessage != null
                ? _buildErrorWidget()
                : _buildContent(),
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 80, color: Colors.red),
            SizedBox(height: 20),
            Text(
              errorMessage!,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, color: Colors.black87),
            ),
            SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: _loadData,
              icon: Icon(Icons.refresh),
              label: Text("إعادة المحاولة"),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.goldPrimary,
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(15),
      child: Column(
        children: [
          _buildNextPrayerCard(),
          SizedBox(height: 15),
          _buildPrayersList(),
          SizedBox(height: 15),
          _buildQiblaCard(),
          SizedBox(height: 15),
          _buildInfoCard(),
        ],
      ),
    );
  }

  Widget _buildNextPrayerCard() {
    return Container(
      padding: EdgeInsets.all(25),
      decoration: BoxDecoration(
        gradient: AppTheme.goldGradient,
        borderRadius: BorderRadius.circular(25),
        boxShadow: [
          BoxShadow(
            color: AppTheme.goldDark.withOpacity(0.5),
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(Icons.access_time, color: Colors.white, size: 50),
          SizedBox(height: 10),
          Text(
            "الصلاة القادمة",
            style: TextStyle(color: Colors.white70, fontSize: 16),
          ),
          SizedBox(height: 5),
          Text(
            nextPrayerName ?? "--",
            style: TextStyle(
              color: Colors.white,
              fontSize: 36,
              fontWeight: FontWeight.bold,
              fontFamily: 'Amiri',
            ),
          ),
          SizedBox(height: 15),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 25, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white, width: 1.5),
            ),
            child: Text(
              "باقي: ${timeUntilNext != null ? PrayerService.formatCountdown(timeUntilNext!) : '--:--:--'}",
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
                fontFamily: 'Amiri',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayersList() {
    if (prayerTimes == null) return SizedBox();

    final prayers = PrayerService.getPrayersList(prayerTimes!);
    final currentPrayer = prayerTimes!.currentPrayer();

    return Container(
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: AppTheme.goldPrimary, width: 2),
        boxShadow: [
          BoxShadow(
            color: AppTheme.goldAccent.withOpacity(0.3),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.list_alt, color: AppTheme.goldPrimary, size: 25),
              SizedBox(width: 10),
              Text(
                "مواقيت اليوم",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.goldDark,
                  fontFamily: 'Amiri',
                ),
              ),
            ],
          ),
          SizedBox(height: 15),
          ...prayers.map((prayer) {
            final isCurrent = PrayerService.prayerName(currentPrayer) == prayer['name'];
            return Container(
              margin: EdgeInsets.only(bottom: 10),
              padding: EdgeInsets.symmetric(horizontal: 15, vertical: 12),
              decoration: BoxDecoration(
                color: isCurrent ? AppTheme.goldAccent.withOpacity(0.3) : Colors.transparent,
                borderRadius: BorderRadius.circular(15),
                border: isCurrent
                    ? Border.all(color: AppTheme.goldPrimary, width: 2)
                    : null,
              ),
              child: Row(
                children: [
                  Text(prayer['icon'], style: TextStyle(fontSize: 24)),
                  SizedBox(width: 15),
                  Expanded(
                    child: Text(
                      prayer['name'],
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.goldDark,
                        fontFamily: 'Amiri',
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: AppTheme.goldGradient,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Text(
                      PrayerService.formatTime(prayer['time']),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildQiblaCard() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: AppTheme.goldPrimary, width: 2),
        boxShadow: [
          BoxShadow(
            color: AppTheme.goldAccent.withOpacity(0.3),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.mosque, color: AppTheme.goldPrimary, size: 25),
              SizedBox(width: 10),
              Text(
                "اتجاه القبلة",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.goldDark,
                  fontFamily: 'Amiri',
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          QiblaCompass(
            qiblaDirection: qiblaDirection ?? 0,
            compassHeading: compassHeading,
          ),
          SizedBox(height: 20),
          Text(
            "وجّه هاتفك حسب الإبرة الذهبية",
            style: TextStyle(
              color: Colors.grey[700],
              fontSize: 14,
            ),
          ),
          SizedBox(height: 5),
          Text(
            "اتجاه القبلة: ${qiblaDirection?.toStringAsFixed(1) ?? '--'}°",
            style: TextStyle(
              color: AppTheme.goldDark,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.goldPrimary.withOpacity(0.1),
            AppTheme.goldAccent.withOpacity(0.2),
          ],
        ),
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: AppTheme.goldPrimary, width: 1),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildInfoItem(Icons.calendar_today, "التاريخ", 
                "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}"),
              _buildInfoItem(Icons.location_on, "طريقة الحساب", "المصرية"),
            ],
          ),
          SizedBox(height: 15),
          Text(
            "✨ جميع الحسابات فلكية - تعمل بدون إنترنت",
            style: TextStyle(
              color: AppTheme.goldDark,
              fontSize: 13,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String label, String value) {
    return Column(
      children: [
        Icon(icon, color: AppTheme.goldPrimary, size: 30),
        SizedBox(height: 5),
        Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
        SizedBox(height: 3),
        Text(
          value,
          style: TextStyle(
            color: AppTheme.goldDark,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}
