import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'mushaf_pdf_screen.dart';
import 'prayer_times_screen.dart';
import 'about_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("القرآن الكريم", style: TextStyle(fontFamily: 'Amiri', fontSize: 26)),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: AppTheme.goldGradient)),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppTheme.goldLight, Colors.white],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.menu_book, size: 120, color: AppTheme.goldPrimary),
              SizedBox(height: 20),
              Text(
                "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                style: TextStyle(
                  fontSize: 28,
                  fontFamily: 'Amiri',
                  color: AppTheme.goldDark,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 40),
              _buildMenuButton(context, Icons.menu_book, "المصحف الشريف - قراءة دون إنترنت", () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => MushafPdfScreen()));
              }),
              SizedBox(height: 15),
              _buildMenuButton(context, Icons.access_time, "مواقيت الصلاة والقبلة", () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => PrayerTimesScreen()));
              }),
              SizedBox(height: 15),
              _buildMenuButton(context, Icons.info, "عن التطبيق", () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => AboutScreen()));
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMenuButton(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 18, horizontal: 25),
        decoration: BoxDecoration(
          gradient: AppTheme.goldGradient,
          borderRadius: BorderRadius.circular(25),
          boxShadow: [
            BoxShadow(
              color: AppTheme.goldDark.withOpacity(0.4),
              blurRadius: 15,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 35),
            SizedBox(width: 20),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Amiri',
                ),
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: Colors.white, size: 20),
          ],
        ),
      ),
    );
  }
}
