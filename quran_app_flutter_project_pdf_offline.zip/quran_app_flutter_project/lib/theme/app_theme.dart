import 'package:flutter/material.dart';

class AppTheme {
  static const Color goldPrimary = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFF9F6EE);
  static const Color goldAccent = Color(0xFFF2D57E);
  static const Color goldDark = Color(0xFFAA8C2C);

  static const LinearGradient goldGradient = LinearGradient(
    colors: [Color(0xFFF9F6EE), Color(0xFFD4AF37), Color(0xFFAA8C2C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static ThemeData get quranTheme {
    return ThemeData(
      scaffoldBackgroundColor: goldLight,
      primaryColor: goldPrimary,
      fontFamily: 'Amiri',
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(gradient: goldGradient),
        ),
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.bold,
          fontFamily: 'Amiri',
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: goldPrimary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 5,
          shadowColor: goldDark,
        ),
      ),
    );
  }
