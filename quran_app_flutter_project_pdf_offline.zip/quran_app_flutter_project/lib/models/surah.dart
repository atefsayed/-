class Surah {
  final int id;
  final String nameArabic;
  final String nameEnglish;
  final String revelationType;
  final int versesCount;
  final int orderInMushaf;

  Surah({
    required this.id,
    required this.nameArabic,
    required this.nameEnglish,
    required this.revelationType,
    required this.versesCount,
    required this.orderInMushaf,
  });

  factory Surah.fromMap(Map<String, dynamic> map) {
    return Surah(
      id: map['id'],
      nameArabic: map['name_arabic'],
      nameEnglish: map['name_english'],
      revelationType: map['revelation_type'],
      versesCount: map['verses_count'],
      orderInMushaf: map['order_in_mushaf'],
    );
  }
}
