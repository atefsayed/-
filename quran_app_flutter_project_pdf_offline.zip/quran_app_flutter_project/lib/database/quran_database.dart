import 'package:sqflite/sqflite.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart';
import 'dart:io';

class QuranDatabase {
  static Database? _database;

  static Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  static Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'quran.db');

    if (!await File(path).exists()) {
      final byteData = await rootBundle.load('assets/quran.db');
      final buffer = byteData.buffer;
      await File(path).writeAsBytes(
        buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes),
      );
    }

    return await openDatabase(path, version: 1);
  }

  static Future<List<Map<String, dynamic>>> getAllSurahs() async {
    final db = await database;
    return await db.query('surahs', orderBy: 'order_in_mushaf ASC');
  }

  static Future<Map<String, dynamic>?> getSurah(int surahId) async {
    final db = await database;
    final result = await db.query(
      'surahs',
      where: 'id = ?',
      whereArgs: [surahId],
      limit: 1,
    );
    return result.isEmpty ? null : result.first;
  }

  static Future<List<Map<String, dynamic>>> getAyahs(int surahId) async {
    final db = await database;
    return await db.query(
      'ayahs',
      where: 'surah_id = ?',
      whereArgs: [surahId],
      orderBy: 'ayah_number ASC',
    );
  }

  static Future<List<Map<String, dynamic>>> searchInQuran(String keyword) async {
    final db = await database;
    return await db.query(
      'ayahs',
      where: 'text_uthmani LIKE ?',
      whereArgs: ['%$keyword%'],
    );
  }
}
}
