import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';

class PrayerService {
  static Future<Coordinates?> getCurrentLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return null;

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return null;
      }

      if (permission == LocationPermission.deniedForever) return null;

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      return Coordinates(position.latitude, position.longitude);
    } catch (e) {
      print('خطأ في تحديد الموقع: $e');
      return null;
    }
  }

  static Future<PrayerTimes?> getPrayerTimes() async {
    final coordinates = await getCurrentLocation();
    if (coordinates == null) return null;

    final params = CalculationMethod.egyptian.getParameters();
    params.madhab = Madhab.hanafi;
    final now = DateTime.now();
    final prayerTimes = PrayerTimes(
      coordinates,
      DateComponents(now.year, now.month, now.day),
      params,
    );

    return prayerTimes;
  }

  static String? getNextPrayer(PrayerTimes prayerTimes) {
    final nextPrayer = prayerTimes.nextPrayer();
    
    if (nextPrayer == Prayer.none) {
      return 'الفجر';
    }
    
    return prayerName(nextPrayer);
  }

  static Duration getTimeUntilNextPrayer(PrayerTimes prayerTimes) {
    final now = DateTime.now();
    final nextPrayer = prayerTimes.nextPrayer();
    
    DateTime nextPrayerTime;
    if (nextPrayer == Prayer.fajr) {
      nextPrayerTime = prayerTimes.fajr;
    } else if (nextPrayer == Prayer.dhuhr) {
      nextPrayerTime = prayerTimes.dhuhr;
    } else if (nextPrayer == Prayer.asr) {
      nextPrayerTime = prayerTimes.asr;
    } else if (nextPrayer == Prayer.maghrib) {
      nextPrayerTime = prayerTimes.maghrib;
    } else if (nextPrayer == Prayer.isha) {
      nextPrayerTime = prayerTimes.isha;
    } else {
      final tomorrow = now.add(Duration(days: 1));
      final tomorrowParameters = CalculationMethod.egyptian.getParameters();
      tomorrowParameters.madhab = Madhab.hanafi;
      final tomorrowParams = PrayerTimes(
        prayerTimes.coordinates,
        DateComponents(tomorrow.year, tomorrow.month, tomorrow.day),
        tomorrowParameters,
      );
      nextPrayerTime = tomorrowParams.fajr;
    }

    return nextPrayerTime.difference(now);
  }

  static String formatCountdown(Duration duration) {
    final hours = duration.inHours.toString().padLeft(2, '0');
    final minutes = (duration.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  static String formatTime(DateTime time) {
    return DateFormat('hh:mm a').format(time);
  }

  static String prayerName(Prayer prayer) {
    switch (prayer) {
      case Prayer.fajr:
        return 'الفجر';
      case Prayer.sunrise:
        return 'الشروق';
      case Prayer.dhuhr:
        return 'الظهر';
      case Prayer.asr:
        return 'العصر';
      case Prayer.maghrib:
        return 'المغرب';
      case Prayer.isha:
        return 'العشاء';
      default:
        return '';
    }
  }

  static List<Map<String, dynamic>> getPrayersList(PrayerTimes prayerTimes) {
    return [
      {'name': 'الفجر', 'time': prayerTimes.fajr, 'icon': '🌙'},
      {'name': 'الشروق', 'time': prayerTimes.sunrise, 'icon': '🌅'},
      {'name': 'الظهر', 'time': prayerTimes.dhuhr, 'icon': '☀️'},
      {'name': 'العصر', 'time': prayerTimes.asr, 'icon': '🌤️'},
      {'name': 'المغرب', 'time': prayerTimes.maghrib, 'icon': '🌇'},
      {'name': 'العشاء', 'time': prayerTimes.isha, 'icon': '🌃'},
    ];
  }
}
