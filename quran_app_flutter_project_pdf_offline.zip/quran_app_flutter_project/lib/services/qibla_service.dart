import 'dart:math';
import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sensors_plus/sensors_plus.dart';

class QiblaService {
  static Future<double?> getQiblaDirection() async {
    try {
      final position = await Geolocator.getCurrentPosition();
      final coordinates = Coordinates(position.latitude, position.longitude);
      
      final qibla = Qibla(coordinates);
      return qibla.direction;
    } catch (e) {
      print('خطأ في حساب القبلة: $e');
      return null;
    }
  }

  static Stream<double> getCompassStream() {
    return magnetometerEventStream().map((event) {
      final degrees = atan2(event.y, event.x) * 180 / pi;
      return (degrees + 360) % 360;
    });
  }

  static double calculateRelativeAngle(double qiblaDirection, double compassHeading) {
    return qiblaDirection - compassHeading;
  }
}
