import 'package:just_audio/just_audio.dart';

class AudioService {
  final AudioPlayer _player = AudioPlayer();

  static const Map<String, String> reciters = {
    "مشاري راشد العفاسي": "afasy",
    "ماهر المعيقلي": "muaiqly",
    "محمد البنا": "banna",
  };

  Future<void> playSurah({
    required String reciterName,
    required int surahNumber,
  }) async {
    final folder = reciters[reciterName]!;
    final fileName = '${surahNumber.toString().padLeft(3, '0')}.mp3';
    final assetPath = 'assets/audio/$folder/$fileName';

    try {
      await _player.setAsset(assetPath);
      await _player.play();
    } catch (e) {
      print('خطأ في التشغيل: $e');
      rethrow;
    }
  }

  void pause() => _player.pause();
  void resume() => _player.play();
  Future<void> stop() async => await _player.stop();
  Future<void> seek(Duration position) async => await _player.seek(position);

  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<Duration> get positionStream => _player.positionStream;

  void dispose() => _player.dispose();
}
